# Focus — Pomodoro v1

Open `index.html` in a modern browser.

Includes:
- Custom Focus / Short Break / Long Break
- Session counter
- Custom daily goal
- Streak starts from any real Focus activity (5 minutes counts)
- Auto-start breaks/focus
- Timestamp-based Smart Timer
- Built-in sound + direct custom audio URL
- Animated luxury gradient background
- Custom image/video background URL
- Spotify/YouTube media card with YouTube thumbnail when possible
- Light/Dark theme
- Responsive design
- Reset confirmation
- Local persistence
